#ifndef TOKENIZER_H
#define TOKENIZER_H

Token* strToToken(char*);
Token* tokenSplit(Token* t);

#endif
